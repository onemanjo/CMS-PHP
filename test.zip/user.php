<?php
require('db_connect.php');
$query_posts = 'SELECT * FROM posts ORDER BY post_id';
$post_statment = $db->prepare($query_posts);
$post_statment->execute();
$db_posts = $post_statment->fetchAll();
$post_statment->closeCursor();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./style/main.css">
    <title>Document</title>
</head>

<body>
    <div class="container">

        <h2>Posts</h2>
        <a href="index.php">back to Admin Panel</a>


        <?php
        foreach ($db_posts as $db_post) :
        ?>
            <p>Index: <?php echo $db_post['post_id'] ?></p>
            <p class="url">URL: <?php echo $db_post['url'] ?></p>
            <p class="phone">Phone: <?php echo $db_post['phone'] ?></p>
            <input type="file">
            <p class="sometext">About: <?php echo $db_post['text'] ?></p>
            <hr>
        <?php endforeach ?>
    </div>
</body>

</html>