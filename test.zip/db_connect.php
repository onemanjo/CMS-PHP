<?php
DEFINE('DB_USER', 'admin');
DEFINE('db_passowrd', "admin");
$dsn = "mysql:host=localhost;dbname=hm1";

try {
    $db = new PDO($dsn, DB_USER, db_passowrd);
} catch (PDOException $e) {
    $err_msg = $e->getMessage();
    include("db_error.php");
    exit();
}
